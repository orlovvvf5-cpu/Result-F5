define(['jquery','require'],function($,require){
 'use strict';
 return function(){
  var self=this,cleanup=null,requests=[],generation=0;
  function read(path){
   if(!/^\/api\/v4\/(account|events)(\?|$)/.test(path))return Promise.reject(new Error('Запрещённый путь'));
   return new Promise(function(resolve,reject){var request=$.ajax({url:path,method:'GET',dataType:'json',timeout:20000});requests.push(request);request.done(resolve).fail(function(xhr){reject(new Error('HTTP '+xhr.status));}).always(function(){requests=requests.filter(function(r){return r!==request;});});});
  }
  function clear(){generation++;requests.forEach(function(r){r.abort();});requests=[];if(cleanup)cleanup();cleanup=null;$('#f5-root').remove();}
  function start(container){
   clear();var current=generation,path=self.params&&self.params.path;
   if(!path){$(container).append($('<p>').text('Не найден путь ресурсов виджета. Проверьте загрузку архива.'));return;}
   path=path.replace(/\/$/,'');
   if(!document.getElementById('f5-styles'))$('<link>',{id:'f5-styles',rel:'stylesheet',href:path+'/styles.css'}).appendTo('head');
   var host=$('<main>',{id:'f5-root'}).appendTo(container);
   require([path+'/core.js',path+'/app.js'],function(Core,App){if(current!==generation)return;cleanup=App.mount(host[0],Core,{probe:async function(){var account=await read('/api/v4/account');var events=await read('/api/v4/events?limit=100');return {accountId:account.id,eventCount:((events._embedded||{}).events||[]).length};}},{implementationDate:self.get_settings().implementation_date});},function(){if(current===generation)host.text('Не удалось загрузить ресурсы прототипа. Проверьте ZIP и консоль браузера.');});
  }
  this.callbacks={
   render:function(){return true;},init:function(){return true;},bind_actions:function(){return true;},
   settings:function(body){if(body&&body.length)start(body);return true;},
   advancedSettings:function(){var target=$('#work_area');if(target.length)start(target);return true;},
   onSave:function(){return true;},destroy:function(){clear();$('#f5-styles').remove();return true;}
  };
 };
});
