(function(root,factory){if(typeof define==='function'&&define.amd)define([],factory);else if(typeof module==='object'&&module.exports)module.exports=factory();else root.F5Core=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const DAY=86400000, iso=t=>new Date(t).toISOString().slice(0,10), date=s=>Date.parse(s+'T00:00:00Z');
const names={pipeline:['Основные продажи','Повторные продажи'],manager:['Анна Смирнова','Илья Волков','Мария Орлова'],source:['Сайт','Рекомендации','Реклама']};
function fixture(){
 let seed=517;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};let leads=[],tasks=[];
 for(let day=date('2025-01-01');day<date('2027-01-01');day+=DAY){
  const later=day>=date('2026-06-01'), count=3+Math.floor(rand()*(later?7:5));
  for(let n=0;n<count;n++){
   const id=leads.length+1, won=rand()<(later?.48:.32), closed=day+(3+Math.floor(rand()*(later?22:33)))*DAY;
   const lead={id,created:day,closed,won,price:(5+Math.floor(rand()*35))*10000,pipeline:names.pipeline[Math.floor(rand()*2)],manager:names.manager[Math.floor(rand()*3)],source:names.source[Math.floor(rand()*3)]};leads.push(lead);
   // A synthetic historical task timeline, never inferred from a present-day task list.
   if(rand()>.2)tasks.push({id,leadId:id,created:day,due:day+7*DAY,completed:day+(later?5:11)*DAY});
  }
 }
 return {leads,tasks,coverage:{from:date('2025-01-01'),to:date('2027-01-01')},demo:true};
}
function validate(p,data){
 const {before,after,implementation}=p;
 if([...before,...after,implementation].some(x=>!Number.isFinite(date(x))))return 'Заполните все даты.';
 const b=before.map(date),a=after.map(date),i=date(implementation);
 if(b[0]>b[1]||a[0]>a[1])return 'Начало периода должно предшествовать окончанию.';
 if(b[1]>=i||a[0]<i)return 'Период «до» должен завершиться до внедрения, период «после» — начаться в дату внедрения или позже.';
 if(b[1]-b[0]!==a[1]-a[0])return 'Для сопоставимости выберите периоды одинаковой длины.';
 if(b[0]<data.coverage.from||a[1]+DAY>data.coverage.to)return 'Демоданные доступны с 01.01.2025 по 31.12.2026.';
 return '';
}
function matches(l,f){return ['pipeline','manager','source'].every(k=>!f[k]||l[k]===f[k]);}
function period(data,range,f){
 const start=date(range[0]),end=date(range[1])+DAY,leads=data.leads.filter(l=>matches(l,f));
 const created=leads.filter(l=>l.created>=start&&l.created<end),won=leads.filter(l=>l.won&&l.closed>=start&&l.closed<end);
 const mature=created.filter(l=>l.created+28*DAY<=data.coverage.to),converted=mature.filter(l=>l.won&&l.closed<l.created+28*DAY);
 const active=leads.filter(l=>l.created<end&&l.closed>=end), ids=new Set(leads.map(l=>l.id));
 const overdue=data.tasks.filter(t=>ids.has(t.leadId)&&t.created<end&&t.due<end&&t.completed>=end);
 const noTask=active.filter(l=>!data.tasks.some(t=>t.leadId===l.id&&t.created<end&&t.completed>=end));
 const duration=won.length?won.reduce((s,l)=>s+(l.closed-l.created)/DAY,0)/won.length:null;
 const metrics=[
  {key:'created',title:'Новые сделки',value:created.length,rows:created,formula:'Количество сделок с датой создания в выбранном периоде.',unit:'count'},
  {key:'won',title:'Успешные сделки',value:won.length,rows:won,formula:'Первое успешное закрытие в периоде. В демомодели повторные открытия отсутствуют.',unit:'count'},
  {key:'conversion',title:'Конверсия за 28 дней',value:mature.length?converted.length/mature.length*100:null,rows:mature,formula:`Из сделок, созданных в периоде и наблюдавшихся 28 дней: доля впервые успешно закрытых раньше создания + 28 суток. ${converted.length} / ${mature.length}. Незрелых сделок: ${created.length-mature.length}.`,unit:'percent'},
  {key:'revenue',title:'Сумма успешных сделок',value:won.reduce((s,l)=>s+l.price,0),rows:won,formula:'Сумма бюджета на момент первого успешного закрытия в периоде. Это не оплаты.',unit:'money'},
  {key:'duration',title:'До успешного закрытия',value:duration,rows:won,formula:'Среднее число суток от создания до первого успешного закрытия для успешных сделок периода.',unit:'days',lower:true},
  {key:'overdue',title:'Просроченные задачи',value:overdue.length,rows:leads.filter(l=>overdue.some(t=>t.leadId===l.id)),count:overdue.length,formula:'Незавершённые задачи с прошедшим сроком на конец периода. В демоданных доступны исторические состояния задач.',unit:'count',lower:true},
  {key:'noTask',title:'Активные без следующей задачи',value:noTask.length,rows:noTask,formula:'Активные на конец периода сделки без любой незавершённой задачи (просроченная также считается следующей). Исторический снимок, не текущее состояние CRM.',unit:'count',lower:true}
 ];return metrics;
}
function compare(data,p){const error=validate(p,data);if(error)return {error};return {before:period(data,p.before,p.filters),after:period(data,p.after,p.filters)};}
function weeks(data,range,f,key){const start=date(range[0]),end=date(range[1])+DAY,out=[];for(let t=start;t<end;t+=7*DAY){const last=Math.min(t+7*DAY,end);out.push({label:iso(t),days:(last-t)/DAY,value:period(data,[iso(t),iso(last-DAY)],f).find(m=>m.key===key).value});}return out;}
return {DAY,date,iso,names,fixture,validate,period,compare,weeks};
});
