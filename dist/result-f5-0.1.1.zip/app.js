(function(root,factory){if(typeof define==='function'&&define.amd)define([],factory);else root.F5App=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function mount(root,C,adapter,options){
 if(root.__f5Cleanup)root.__f5Cleanup();
 const controller=new AbortController();
 const data=C.fixture(),fmt=new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1});
 let params={implementation:'2026-06-01',before:['2026-05-04','2026-05-31'],after:['2026-06-01','2026-06-28'],filters:{}}, result, chartKey='created', destroyed=false;
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const value=m=>m.value===null?'Нет данных':(m.unit==='money'&&m.value>=1000000?new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(m.value/1000000)+' млн':fmt.format(m.value))+(m.unit==='money'?' ₽':m.unit==='percent'?'%':m.unit==='days'?' дн.':'');
 const select=(k,label)=>`<label>${label}<select data-filter="${k}"><option value="">Все</option>${C.names[k].map(n=>`<option>${n}</option>`).join('')}</select></label>`;
 root.innerHTML=`<div class="f5-shell"><header><div class="f5-brand">Ф<span>5</span></div><div><div class="eyebrow">КОМАНДА Ф5 / АНАЛИТИКА ПРОДАЖ</div><h1>Результат Ф5</h1></div><span class="f5-badge">ДЕМО · ВЫМЫШЛЕННЫЕ ДАННЫЕ</span></header>
 <section class="f5-intro"><h2>Изменения, которые можно увидеть</h2><p>Сравните работу отдела продаж до и после внедрения. Больше контекста — точнее выводы.</p></section>
 <div class="f5-note"><strong>Это интерактивный прототип.</strong> Все сделки, суммы и исторические состояния вымышлены. Аккаунт amoCRM не подключён. Изменения не доказывают влияние Ф5.</div>
 <section class="f5-controls"><div class="f5-periods"><label>Дата внедрения Ф5<input type="date" id="f5-implementation" value="2026-06-01"></label><fieldset><legend><i class="f5-dot before"></i>До внедрения</legend><input aria-label="Начало периода до" type="date" id="f5-b0" value="2026-05-04"><span>—</span><input aria-label="Конец периода до" type="date" id="f5-b1" value="2026-05-31"></fieldset><fieldset><legend><i class="f5-dot after"></i>После внедрения</legend><input aria-label="Начало периода после" type="date" id="f5-a0" value="2026-06-01"><span>—</span><input aria-label="Конец периода после" type="date" id="f5-a1" value="2026-06-28"></fieldset><button id="f5-auto">По 28 дней</button></div><div class="f5-filters">${select('pipeline','Воронка')}${select('manager','Менеджер')}${select('source','Источник')}<div class="f5-timezone">Часовой пояс демо: UTC<br>Границы дней включены</div></div></section>
 <p id="f5-error" role="alert"></p><div id="f5-report"><div class="f5-section-title"><h2>Было → стало</h2><span>Равные периоды · <b id="f5-days">28</b> дней</span></div><section class="f5-cards" id="f5-cards"></section>
 <section class="f5-chart-panel"><div class="f5-section-title"><div><h2>Динамика по неделям</h2><p>Недели от начала каждого периода; последняя может быть неполной.</p></div><select id="f5-chart-key" aria-label="Показатель графика"></select></div><div class="f5-legend"><span><i class="f5-dot before"></i>До внедрения</span><span><i class="f5-dot after"></i>После внедрения</span></div><div id="f5-chart"></div></section></div>
 <section class="f5-history"><div><div class="eyebrow">ЧЕСТНЫЙ РАСЧЁТ</div><h2>История важнее текущего состояния</h2><p>Бюджет, ответственный и задачи сегодня не описывают прошлое. Для реального аккаунта расчёт включается только после проверки полноты событий.</p></div><div class="f5-history-card"><span class="f5-warning">Недостаточно исторических данных</span><p>Если события не позволяют восстановить показатель, вместо значения показываем этот статус. История задач и бюджета требует отдельной проверки.</p></div></section>
 <section class="f5-connection"><div><h2>Подключение amoCRM</h2><p>Приватная интеграция · только чтение · без токенов в браузерном хранилище</p></div><button id="f5-connect">${adapter?'Проверить чтение API':'Как подключить аккаунт'}</button><p id="f5-api" role="status"></p></section>
 <footer>Результат Ф5 · прототип 0.1 <span>Сумма сделок ≠ оплаты. Рост сделок ≠ доказанный эффект внедрения.</span></footer>
 <dialog id="f5-dialog"><div class="f5-dialog-head"><h2 id="f5-dialog-title"></h2><button id="f5-close" aria-label="Закрыть">✕</button></div><div id="f5-dialog-body"></div></dialog></div>`;
 const q=s=>root.querySelector(s);
 function draw(){
  params.implementation=q('#f5-implementation').value;params.before=[q('#f5-b0').value,q('#f5-b1').value];params.after=[q('#f5-a0').value,q('#f5-a1').value];
  result=C.compare(data,params);q('#f5-error').textContent=result.error||'';q('#f5-report').hidden=!!result.error;if(result.error)return;
  q('#f5-days').textContent=(C.date(params.before[1])-C.date(params.before[0]))/C.DAY+1;
  q('#f5-cards').innerHTML=result.before.map((b,i)=>{const a=result.after[i],delta=a.value===null||b.value===null?null:a.value-b.value,good=delta!==null&&(b.lower?delta<0:delta>0);let change='Нет базы для сравнения';if(delta!==null)change=b.unit==='percent'?`${delta>0?'+':''}${fmt.format(delta)} п.п.`:b.value===0?(a.value===0?'Без изменений':'База равна нулю'): `${delta>0?'+':''}${fmt.format(delta/b.value*100)}%`;
   return `<article class="f5-card"><div class="f5-card-heading"><h3>${b.title}</h3><span class="f5-number">0${i+1}</span></div><div class="f5-values"><div><small>БЫЛО</small><strong>${value(b)}</strong></div><span class="f5-arrow">→</span><div><small>СТАЛО</small><strong>${value(a)}</strong></div></div><div class="f5-card-foot"><span class="f5-delta ${good?'good':delta===0||delta===null?'neutral':'bad'}">${change}</span><button data-detail="${i}">Расчёт и сделки ↗</button></div><small>${b.count??b.rows.length} → ${a.count??a.rows.length} ${b.key==='overdue'?'задач':'сделок'} в расчёте</small></article>`;
  }).join('');
  q('#f5-chart-key').innerHTML=result.before.map(m=>`<option value="${m.key}" ${m.key===chartKey?'selected':''}>${m.title}</option>`).join('');drawChart();
 }
 function drawChart(){
  const b=C.weeks(data,params.before,params.filters,chartKey),a=C.weeks(data,params.after,params.filters,chartKey),max=Math.max(1,...b.concat(a).map(w=>w.value||0));
  q('#f5-chart').innerHTML=`<div class="f5-bars">${b.map((w,i)=>`<div class="f5-week"><div class="f5-bar-pair">${[w,a[i]].map((v,j)=>`<div class="f5-bar-column"><span>${v.value===null?'—':fmt.format(v.value)}</span><div class="f5-bar ${j?'after':'before'}" style="height:${v.value===null?0:Math.max(2,v.value/max*140)}px"></div></div>`).join('')}</div><strong>Неделя ${i+1}${w.days<7?' · '+w.days+' дн.':''}</strong><small>${esc(w.label)} / ${esc(a[i].label)}</small></div>`).join('')}</div>`;
 }
 function show(title,html){q('#f5-dialog-title').textContent=title;q('#f5-dialog-body').innerHTML=html;q('#f5-dialog').showModal();}
 root.addEventListener('change',e=>{if(e.target.id==='f5-chart-key'){chartKey=e.target.value;drawChart();return;}if(e.target.dataset.filter)params.filters[e.target.dataset.filter]=e.target.value;draw();},{signal:controller.signal});
 root.addEventListener('click',async e=>{
  const detail=e.target.closest('[data-detail]');
  if(detail&&!result.error){const i=Number(detail.dataset.detail),b=result.before[i],a=result.after[i];show(b.title,`<p>${esc(b.formula)}</p><p><strong>После:</strong> ${esc(a.formula)}</p><p>Отборы в демо используют вымышленные исторические атрибуты. Список конверсии — её знаменатель.</p>${[b,a].map((m,j)=>`<h3>${j?'После':'До'} · ${m.rows.length} сделок</h3><div class="f5-table-scroll"><table><thead><tr><th>Демо ID</th><th>Менеджер</th><th>Создана</th><th>Бюджет</th></tr></thead><tbody>${m.rows.map(l=>`<tr><td>ДЕМО-${l.id}</td><td>${esc(l.manager)}</td><td>${C.iso(l.created)}</td><td>${fmt.format(l.price)} ₽</td></tr>`).join('')||'<tr><td colspan="4">Нет сделок в выборке</td></tr>'}</tbody></table></div>`).join('')}<p>Это демонстрационные записи; ссылок на настоящие сделки здесь нет. Для проверенных реальных ID переход: /leads/detail/ID в текущем аккаунте.</p>`);}
  if(e.target.id==='f5-close')q('#f5-dialog').close();
  if(e.target.id==='f5-auto'){const t=C.date(q('#f5-implementation').value);if(!Number.isFinite(t))return;q('#f5-b0').value=C.iso(t-28*C.DAY);q('#f5-b1').value=C.iso(t-C.DAY);q('#f5-a0').value=C.iso(t);q('#f5-a1').value=C.iso(t+27*C.DAY);draw();}
  if(e.target.id==='f5-connect'){
   if(!adapter){show('Приватная интеграция без собственного сервера','<p>Загрузите ZIP в приватную интеграцию тестового аккаунта. Откройте её расширенные настройки: там появится проверка чтения API из сессии amoCRM.</p><p>Проверка выполняет только GET /api/v4/account и GET /api/v4/events?limit=100. Она не переключает отчёт на реальные данные.</p><p>OAuth-код, client_secret и refresh_token нельзя безопасно обменивать и хранить в ZIP. Здесь OAuth-обмен не реализован. Без собственного сервера используется контекст установленного виджета; его возможности и права требуют проверки в аккаунте.</p>');return;}
   e.target.disabled=true;q('#f5-api').textContent='Проверяем доступ к API…';
   try{const probe=await adapter.probe();if(!destroyed)q('#f5-api').textContent=`Чтение API доступно. ID аккаунта: ${probe.accountId}. Получено событий в пробной странице: ${probe.eventCount}. Это не полная история. Отчёт остаётся демонстрационным.`;}catch(err){if(!destroyed)q('#f5-api').textContent='Не удалось проверить API: '+err.message+'. Отчёт остаётся демонстрационным.';}finally{if(!destroyed)q('#f5-connect').disabled=false;}
  }
 },{signal:controller.signal});
 if(options&&/^\d{4}-\d{2}-\d{2}$/.test(options.implementationDate||'')&&Number.isFinite(C.date(options.implementationDate))){const t=C.date(options.implementationDate);q('#f5-implementation').value=options.implementationDate;q('#f5-b0').value=C.iso(t-28*C.DAY);q('#f5-b1').value=C.iso(t-C.DAY);q('#f5-a0').value=C.iso(t);q('#f5-a1').value=C.iso(t+27*C.DAY);}
 draw();root.__f5Cleanup=()=>{destroyed=true;controller.abort();root.innerHTML='';delete root.__f5Cleanup;};return root.__f5Cleanup;
}
return {mount};
});
